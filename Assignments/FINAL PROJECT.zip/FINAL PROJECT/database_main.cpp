#include "menu.h"

using namespace std;

int main() {
    Menu test;
    Database info;
    test.start_menu(info);
}