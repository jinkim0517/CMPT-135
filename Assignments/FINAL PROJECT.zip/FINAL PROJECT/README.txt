CMPT 135 Final Project
======================

Names of Team Members
---------------------
Jin Kim, jka287@sfu.ca, 301539203


Instructions for Compiling and Running
--------------------------------------

Type "make" into the terminal and then run the program (./database_main_test)


Limitations
-----------

Did not fully implement ncurses.


Known Bugs
----------

No known bugs


Extra Features
--------------

Extra boolean field (Single or Album)